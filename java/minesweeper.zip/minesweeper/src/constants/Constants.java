package constants;

public interface Constants {
    public final Integer TWENTY_SIX = 26;
    public final Integer N_PER_PAGE = 5;
    public final String[] VALID_TYPES = {
            "mine", "not_open", "number"
    };
}
