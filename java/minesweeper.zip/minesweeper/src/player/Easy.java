package player;

public class Easy extends WinLoseData {

}
