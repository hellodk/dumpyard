package player;

public abstract class GameData {

}
