package player;

public class Hard extends WinLoseData {

}
